﻿#pragma once
#include "hooker.hpp"


static hooker* HOOK;